private static void exerciseFactorizer(Computable<Long, long[]> f) throws InterruptedException {
        final int threadCount = 16;
        final long start = 10_000_000_000L, range = 20_000L;

        for (int t = 0; t < threadCount; t++) {
            final int finalT = t;
            new Thread(() -> {
                for (long i = start; i < start+range; i++) {
                    try {
                        f.compute(i);
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                };
                for (long i = start+range + finalT * 5_000; i < 10_000_039_999L + 1 + finalT * 5_000; i++) {
                    try {
                        f.compute(i);
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                };
            }).run();
        } 
