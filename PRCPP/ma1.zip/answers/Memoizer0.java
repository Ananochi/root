import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;

public class Memoizer0<A, V> implements Computable<A, V> {
    private final ConcurrentMap<A, V> cache = new ConcurrentHashMap<>();
    private final Computable<A, V> c;

    public Memoizer0(Computable<A, V> c) {
        this.c = c;
    }

    public V compute(final A arg) throws InterruptedException {
        return cache.computeIfAbsent(arg, n -> {
            try {
                return c.compute(arg);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            return null;
        });
    }
}



